<?php
$conf = array(
	'desc'=>'develop',
	'host'=>'localhost',
	'user'=>'root',
	'pass'=>'Student123!',
	'dbname'=>'gGrades',
);
?>
