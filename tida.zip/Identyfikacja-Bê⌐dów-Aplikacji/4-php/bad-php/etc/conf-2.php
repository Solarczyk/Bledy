<?php
$conf = array(
	'desc'=>'production',
	'host'=>'edu.gplweb.pl',
	'user'=>'root',
	'pass'=>'MegaTajneHas!o',
	'dbname'=>'gGrades',
);
?>
